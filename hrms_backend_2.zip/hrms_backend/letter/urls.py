from django.urls import path
from letter.views import offer_letter_view

app_name = 'myapp'

urlpatterns = [
    path('offer-letter/', offer_letter_view, name='offer-letter'),
    # Add more URL patterns if needed
]