from django.contrib import admin
from letter.models import Employee
# Register your models here.


admin.site.register(Employee)