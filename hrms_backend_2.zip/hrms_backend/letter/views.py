from django.shortcuts import render
from letter.models import Employee
from letter.serializers import EmployeeSerializer

def offer_letter_view(request):
    employee = Employee.objects.first()  # Retrieve the first employee from the database, you can modify this based on your requirement
    serializer = EmployeeSerializer(employee)
    context = {
        'employee_data': serializer.data
    }
    return render(request, 'offer_letter.html', context)
