from django.db import models
from common.models import BaseModel


class Role(BaseModel):
    name=models.CharField(max_length=255)
    
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Role'
        verbose_name_plural = 'Roles'
        
        
class Permission(BaseModel):
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    module_name = models.CharField(max_length=255)
    feature_name = models.CharField(max_length=255)
    access_rights = models.CharField(max_length=255)

    def __str__(self):
        return self.name       
    
class RolePermission(models.Model):
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.role} - {self.permission}'    