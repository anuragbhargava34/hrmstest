# from django.shortcuts import render

from rest_framework import viewsets
from rolespermission.models import Role, Permission, RolePermission
from rolespermission.serializers import RoleSerializer, PermissionSerializer, RolePermissionSerializer

class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer

class PermissionViewSet(viewsets.ModelViewSet):
    queryset = Permission.objects.all()
    serializer_class = PermissionSerializer

class RolePermissionViewSet(viewsets.ModelViewSet):
    queryset = RolePermission.objects.all()
    serializer_class = RolePermissionSerializer
