from django.contrib import admin
from django.urls import path, include
from  rolespermission.views import RoleViewSet,PermissionViewSet,RolePermissionViewSet
from rest_framework import routers


router = routers.DefaultRouter()
router.register('roles', RoleViewSet)
router.register('permission', PermissionViewSet)
router.register('rolesandpermission', RolePermissionViewSet)

urlpatterns = [
    path('rolespermission/', include(router.urls)),
 
]