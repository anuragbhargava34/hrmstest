from .base import *


DATABASES = {
    "default": dj_database_url.config(
        # Feel free to alter this value to suit your needs.
        default=config("DATABASE_URL"),
        conn_max_age=600,
    )
}
