from rest_framework.authentication import BaseAuthentication
import jwt
from account.models import User
from hrms_be.settings import SIMPLE_JWT
# from jwt_utils.jwt_validator import jwt_validator
       

class JWTAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.headers.get('Authorization')
         
        

        if not auth_header:
            return None

        access_token = auth_header.split(' ')[1]

        payload = jwt.decode(f'SIMPLE_JWT.AUTH_HEADER_TYPES[0] {access_token}', 'secret', algorithms=['HS256'])

        user = User.objects.get(username=payload['username'])

        return (user, access_token)

    def authenticate_header(self, request):
        return 'Bearer realm="API"'
    