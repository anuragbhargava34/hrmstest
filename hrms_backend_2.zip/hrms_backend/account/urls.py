from django.urls import path,include
from rest_framework_simplejwt.views import TokenRefreshView

from account import views

app_name = "account"

urlpatterns = [
    path("login/", views.UserLoginAPIView.as_view(), name="login-account"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token-refresh"),
    path("logout/", views.UserLogoutAPIView.as_view(), name="logout-account"),
    path("user/", views.UserAPIView.as_view(), name="user-info"),
    # path("api-auth/", include("rest_framework.urls")),

]
