# from django.db import models

import uuid

from django.db import models
from django.contrib.auth.models import PermissionsMixin
from django.contrib.auth.base_user import AbstractBaseUser
from django.utils import timezone

from .managers import CustomUserManager
from common.models import BaseModel

# Create your models here.
class User(AbstractBaseUser, PermissionsMixin, BaseModel):

    ROLE_CHOICES = (
        
        ('admin', 'Admin'),
        ('vendor', 'Vendor'),
        ('company', 'Company'),
        ('employee', 'Employee'),
    
    )
    
    class Meta:
        verbose_name = 'user'
        verbose_name_plural = 'users'

    # Roles created here
    username=models.CharField(max_length=40,unique=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    last_login_at = models.DateTimeField('last login', null=True, blank=True)
    last_login_ip = models.CharField(max_length=255)
    source_type = models.CharField(max_length=20,choices= ROLE_CHOICES)
    source_id = models.CharField(max_length=10, blank=True)   
    

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
        return self.username 



   