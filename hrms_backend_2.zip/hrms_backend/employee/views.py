from django.shortcuts import render
from rest_framework import viewsets 
from employee.models import Employee
from employee.serializers import EmployeeSerializer
from company.permissions import IsAdminOrReadOnly,IsCompanyOrReadOnly
from rest_framework.permissions import IsAuthenticated


class EmployeeViewSet(viewsets.ModelViewSet):

    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    permission_classes= [IsAuthenticated,IsAdminOrReadOnly]
