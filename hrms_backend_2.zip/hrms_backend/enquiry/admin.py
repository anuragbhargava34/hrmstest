from django.contrib import admin
from enquiry.models import Enquiry
# Register your models here.


admin.site.register(Enquiry)
