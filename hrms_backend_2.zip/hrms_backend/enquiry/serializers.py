from rest_framework import serializers
from enquiry.models import Enquiry


class EnquirySerializer(serializers.ModelSerializer):
    class Meta:
        model = Enquiry
        fields = '__all__'

    def create(self, validated_data):
        return Enquiry.objects.create(**validated_data)
