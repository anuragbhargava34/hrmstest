from django.db import models


class Enquiry(models.Model):
    company_name = models.CharField(max_length=255, unique=True)
    contact_email = models.EmailField()
    contact_number = models.CharField(max_length=255)
    contact_website = models.CharField(max_length=255)
    contact_name = models.CharField(max_length=255)
    is_active = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Enquiry'
        verbose_name_plural = 'Enquiries'

    def __str__(self):
        return self.company_name
