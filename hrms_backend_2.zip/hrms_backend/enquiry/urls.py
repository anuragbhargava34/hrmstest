from enquiry.views import *
from .views import EnquiryViewset
from rest_framework import routers
from django.urls import include, path


router = routers.DefaultRouter()
router.register(r'enquiry', EnquiryViewset)


urlpatterns = [
    path('enquiry/', include(router.urls)),

]
