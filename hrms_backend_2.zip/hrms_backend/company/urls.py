from django.contrib import admin
from django.urls import path, include
from  company.views import*
from rest_framework import routers


router = routers.DefaultRouter()
router.register('companies', CompanyViewSet)
router.register('companydetails',CompanyDetailsViewSet)
router.register('countries', CountryViewSet)
router.register('states', StateViewSet)
router.register('cities', CityViewSet)

urlpatterns = [
    path('details/', include(router.urls)),
    
    
]