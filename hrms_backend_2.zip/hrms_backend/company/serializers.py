from rest_framework import serializers
from company.models import *




class CompanySerializer(serializers.ModelSerializer):
    # user = UserLoginSerializer(read_only=True)

    class Meta:
        model = Company
        fields = '__all__'


class CompanyDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyDetails
        fields = '__all__'
        depth=1

class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = ['id', 'name', 'iso_2', 'iso_3']
        
        

class StateSerializer(serializers.ModelSerializer):
    # country = CountrySerializer(read_only=True)

    class Meta:
        model = State
        fields = ['id','name', 'country', 'abbrevative']
        depth=1

class CreateStateSerializer(serializers.ModelSerializer):
    # country = CountrySerializer(read_only=True)

    class Meta:
        model = State
        fields = ['id','name', 'country', 'abbrevative']        
    

class CitySerializer(serializers.ModelSerializer):
    # state = StateSerializer()

    class Meta:
        model = City
        fields = ['id', 'name', 'state', 'abbrevative']
        depth=1
        
class CreateCitySerializer(serializers.ModelSerializer):
    # state = StateSerializer()

    class Meta:
        model = City
        fields = ['id', 'name', 'state', 'abbrevative']
             
