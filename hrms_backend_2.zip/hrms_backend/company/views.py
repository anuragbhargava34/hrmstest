from django.shortcuts import render
from  company.models import*
from company.serializers import*
from rest_framework import viewsets
from .permissions import IsAdminOrReadOnly, IsCompanyOrReadOnly
from rest_framework.permissions import IsAuthenticated

class CompanyViewSet(viewsets.ModelViewSet):

    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    permission_classes= [IsAuthenticated,IsAdminOrReadOnly]

     

class CompanyDetailsViewSet(viewsets.ModelViewSet):

    queryset=CompanyDetails.objects.all()
    serializer_class = CompanyDetailsSerializer
    permission_classes= [IsAuthenticated,IsAdminOrReadOnly]


class CountryViewSet(viewsets.ModelViewSet):
    queryset = Country.objects.all()
    serializer_class = CountrySerializer
    

class StateViewSet(viewsets.ModelViewSet):
    queryset = State.objects.all()
    serializer_class = StateSerializer
    
    
    def get_serializer_class(self):
        if self.action == "create":
            return CreateStateSerializer
        return StateSerializer

class CityViewSet(viewsets.ModelViewSet):
    queryset = City.objects.all()
    serializer_class = CitySerializer
    
    
    def get_serializer_class(self):
        if self.action == "create":
            return CreateCitySerializer
        return CitySerializer