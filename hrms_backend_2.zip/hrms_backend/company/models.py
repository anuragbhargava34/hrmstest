from django.db import models
from common.models import BaseModel
# from django.contrib.postgres.fields import CICharFielde



class Company(BaseModel):
    name = models.CharField(max_length=255)
    logo = models.ImageField(upload_to='images/')
    website = models.CharField(max_length=255)
    subdomain = models.CharField(max_length=100)
    domain = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Company'
        verbose_name_plural = 'Companies'

class CompanyDetails(BaseModel):
    company_overview=models.ForeignKey(Company,on_delete=models.CASCADE)
    email = models.EmailField()
    contact = models.CharField(max_length=15)
    address = models.TextField()
    person_name = models.CharField(max_length=255)
    designation = models.CharField(max_length=255)

    def __str__(self):
        return self.email

    class Meta:
        verbose_name = 'CompanyDetails'
        verbose_name_plural = 'CompanyDetails'

class AddressModel(BaseModel):
    line_1 = models.TextField()
    line_2 = models.TextField()
    landmark = models.TextField()
    city = models.CharField(max_length=255)
    country = models.CharField(max_length = 255)
    state = models.CharField(max_length=255)
    pincode = models.IntegerField()


    class Meta:
        abstract = True

        
class Country(BaseModel):
    name = models.CharField(max_length=255,unique=True)
    iso_2 = models.CharField(max_length=2,unique=True)
    iso_3 = models.CharField(max_length=3,unique=True)
    
    
    def save(self, **validated_data):
        self.name = self.name.upper()  # Convert value to uppercase before saving
        super(Country, self).save(**validated_data)

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = 'Country'
        verbose_name_plural = 'Countries'

class State(BaseModel):
    name = models.CharField(max_length=255)
    country = models.ForeignKey(Country, on_delete=models.CASCADE)
    abbrevative = models.CharField(max_length=10,blank=True)
    
    def save(self, **validated_data):
        self.name = self.name.upper()  # Convert value to uppercase before saving
        super(State, self).save(**validated_data)
    

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = 'State'
        verbose_name_plural = 'States'

class City(BaseModel):
    name = models.CharField(max_length=255)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    abbrevative = models.CharField(max_length=10,blank=True)
    
    def save(self, **validated_data):
        self.name = self.name.upper()  # Convert value to uppercase before saving
        super(City, self).save(**validated_data)

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = 'City'
        verbose_name_plural = 'City'
    
