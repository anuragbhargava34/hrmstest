#!/usr/bin/env bash
set -o errexit

python manage.py collectstatic --no-input
python manage.py makemigrations
python manage.py migrate

gunicorn hrms_be.wsgi:application
